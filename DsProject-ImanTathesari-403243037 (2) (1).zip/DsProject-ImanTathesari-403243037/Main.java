import java.util.Random;

interface RMQStructure {
    void build(int[] A);
    int query(int l, int r);
}

class NaiveRMQ implements RMQStructure {
    private int[] data;

    
    public void build(int[] A) {
        this.data=A;
    }

    
    public int query(int l, int r) {
        int minIdx=l;
        for (int i = l+1;i<=r;i++) {
            if (data[i]<data[minIdx]) {
                minIdx=i;
            }
        }
        return minIdx;
    }
}

class SparseTableRMQ implements RMQStructure {
    private int[][] st;
    private int[] data;

    
    public void build(int[] A) {
        this.data =A;
        int n =A.length;
        int maxLog = (int)(Math.log(n)/Math.log(2)) + 1;
        st = new int[n][maxLog];
        for (int i = 0; i < n; i++) st[i][0] = i;
        for (int j = 1; j < maxLog; j++) {
            for (int i=0;i+(1<<j) <=n;i++) {
                int left=st[i][j-1];
                int right = st[i+ (1<<(j-1))][j - 1];
                st[i][j] = (data[left]<=data[right])? left:right;
            }
        }
    }

    
    public int query(int l, int r) {
        int length = r - l + 1;
        int j = (int) (Math.log(length) /Math.log(2));
        int left = st[l][j];
        int right = st[r -(1<<j) + 1][j];
        return (data[left]<=data[right]) ? left:right;
    }
}

class SegmentTreeRMQ implements RMQStructure {
    private int[] tree;
    private int[] data;
    private int n;

    
    public void build(int[] A) {
        this.data = A;
        this.n = A.length;
        tree = new int[4 * n];
        buildTree(1,0, n-1);
    }

    private void buildTree(int node,int start, int end) {
        if (start==end) {
            tree[node]=start;
            return;
        }
        int mid = (start+end) / 2;
        buildTree(2 * node, start, mid);
        buildTree(2 * node+1, mid+1, end);
        int left = tree[2*node];
        int right = tree[2*node+1];
        tree[node] = (data[left] <= data[right]) ?left: right;
    }

    
    public int query(int l, int r) {
        return queryTree(1, 0, n - 1, l, r);
    }

    private int queryTree(int node, int start, int end, int l, int r) {
        if (r < start||end<l) return -1;
        if (l <= start&&end <= r) return tree[node];
        int mid = (start+end)/2;
        int p1 = queryTree(2 *node,start, mid, l, r);
        int p2 = queryTree(2 * node+1,mid+1, end, l, r);
        if (p1 ==-1) return p2;
        if (p2 ==-1) return p1;
        return (data[p1] <= data[p2]) ? p1 : p2;
    }
}

class BlockDecompositionRMQ implements RMQStructure {
    private int[] data;
    private int[] blocks;
    private int blockSize;

    
    public void build(int[] A) {
        this.data = A;
        int n=A.length;
        blockSize =(int) Math.sqrt(n);
        int numBlocks =(int) Math.ceil((double) n / blockSize);
        blocks = new int[numBlocks];
        for (int i = 0; i<numBlocks; i++) {
            int minIdx =i *blockSize;
            for (int j =i*blockSize + 1; j<Math.min((i+1)*blockSize, n); j++) {
                if (data[j] < data[minIdx]) minIdx=j;
            }
            blocks[i] = minIdx;
        }
    }

    
    public int query(int l, int r) {
        int minIdx = l;
        int startBlock = l/blockSize;
        int endBlock = r/blockSize;
        if (startBlock == endBlock) {
            for (int i = l+1; i<=r; i++)
                if (data[i]<data[minIdx]) minIdx = i;
        } else {
            for (int i = l + 1; i<(startBlock+1)*blockSize; i++)
                if (data[i]<data[minIdx]) minIdx = i;
            for (int i = startBlock+1; i<endBlock; i++)
                if (data[blocks[i]]<data[minIdx]) minIdx = blocks[i];
            for (int i = endBlock *blockSize; i<= r;i++)
                if (data[i]<data[minIdx]) minIdx=i;
        }
        return minIdx;
    }
}



class OptimizedRMQ implements RMQStructure {
    private int[] data;
    private int[][] st;
    private int[] blockMinIndices;
    private final int blockSize = 16; 

    
    public void build(int[] A) {
        this.data = A;
        int n = A.length;
        int numBlocks = (int)Math.ceil((double) n/blockSize);
        blockMinIndices = new int[numBlocks];

        for (int i = 0; i <numBlocks; i++) {
            int start = i *blockSize;
            int end = Math.min(start+blockSize, n);
            int minIdx = start;
            for (int j = start+1; j<end; j++) {
                if (data[j]<data[minIdx]) minIdx = j;
            }
            blockMinIndices[i] = minIdx;
        }

        int m = blockMinIndices.length;
        int maxLog = (int)(Math.log(m)/Math.log(2)) + 1;
        st = new int[m][maxLog];
        for (int i = 0; i< m; i++) st[i][0]=blockMinIndices[i];
        for (int j = 1; j < maxLog; j++) {
            for (int i = 0; i+(1<<j) <= m; i++) {
                int leftIdx =st[i][j - 1];
                int rightIdx =st[i + (1 << (j - 1))][j - 1];
                st[i][j] = (data[leftIdx]<=data[rightIdx]) ? leftIdx : rightIdx;
            }
        }
    }

    
    public int query(int l, int r) {
        int bL = l/blockSize;
        int bR = r/blockSize;

        if (bL == bR) {
            return linearQuery(l, r);
        } else {
            int resL = linearQuery(l, (bL+1)*blockSize - 1);
            int resR = linearQuery(bR*blockSize,r);
            int finalIdx = (data[resL]<=data[resR]) ? resL:resR;

            if (bL + 1 < bR) {
                int length = (bR-1)-(bL+1) + 1;
                int j = (int) (Math.log(length)/Math.log(2));
                int midL =st[bL+1][j];
                int midR =st[bR -(1<<j)][j];
                int midIdx =(data[midL]<=data[midR]) ?midL: midR;
                
                if (data[midIdx] < data[finalIdx]) finalIdx = midIdx;
                else if (data[midIdx] == data[finalIdx]) finalIdx = Math.min(finalIdx, midIdx);
            }
            return finalIdx;
        }
    }

    private int linearQuery(int l, int r) {
        int m = l;
        for (int i = l + 1; i <= r; i++) if (data[i] < data[m]) m = i;
        return m;
    }
}

public class Main {
   public static void main(String[] args) {
    
    int[] nValues = {1000, 10000, 20000, 50000, 100000};
    int numQueries = 10000;
    Random rand = new Random();

    

    for (int n : nValues) {
        int[] A = new int[n];
        for (int i = 0; i < n; i++)A[i]=rand.nextInt(1000000001);

        RMQStructure[] methods = {
            new NaiveRMQ(),
            new SparseTableRMQ(),
            new SegmentTreeRMQ(),
            new BlockDecompositionRMQ(),
            new OptimizedRMQ() 
        };

        for (RMQStructure m : methods) {
            System.gc();
            try { Thread.sleep(200); } catch (Exception e) {} 
            
            long m1 = Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
            long t1 = System.currentTimeMillis();
            
            m.build(A);
            for (int q = 0; q < numQueries; q++) {
                int l = rand.nextInt(n);
                int r = rand.nextInt(n - l) + l;
                m.query(l, r);
            }
            
            long t2=System.currentTimeMillis();
            long m2=Runtime.getRuntime().totalMemory() -Runtime.getRuntime().freeMemory();
            
            String name = m.getClass().getSimpleName();
            System.out.println(n+","+name+","+(t2-t1) + "," +Math.max(0, (m2 - m1) / 1024));
        }
    }
}
}